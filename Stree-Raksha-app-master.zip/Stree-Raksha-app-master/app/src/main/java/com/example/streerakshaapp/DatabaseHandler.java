package com.example.streerakshaapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHandler extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "mylist.db" ;
    public static  final String TABLE_NAME ="mylist_data";
    public  static final String COL1="ID";
    public static final String COL2="ITEM1";

    public DatabaseHandler (Context context){super(context,DATABASE_NAME,null,1);}
    @Override
    public void onCreate(SQLiteDatabase db){
            String createTable = "CREATE TABLE " +TABLE_NAME+"(ID INTEGER PRIMARY KEY AUTOINCREMENT, " + "ITEM1 TEXT )";
            db.execSQL( createTable );

    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int i, int i1) {
        String a = "DROP TABLE IF EXISTS mylist_data ";
        db.execSQL(a);
        onCreate( db );

    }
    public boolean addData (String item1) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put( COL2,item1 );

        long result = db.insert(TABLE_NAME,null,contentValues);

        if (result==-1) {
            return false;
        } else {
            return true;

        }
    }

    public Cursor getListContents(){
        SQLiteDatabase db = this.getWritableDatabase();

        Cursor data = db.rawQuery("SELECT* FROM  "+ TABLE_NAME,null);

        return data;

    }
}
